import StoreStorage, { StorageKey } from './UserStorage'

const storage = new StoreStorage()

export default storage
export { StorageKey }
